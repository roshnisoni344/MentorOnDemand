package com.cognizant.MOD;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ModApplication {

	public static void main(String[] args) {
		SpringApplication.run(ModApplication.class, args);
	}

}
